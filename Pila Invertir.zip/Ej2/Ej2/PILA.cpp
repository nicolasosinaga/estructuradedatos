#include "StdAfx.h"
#include "PILA.h"


PILA::PILA(void)
{
	P[M]=0;
	puntero=-1;
}
int PILA::Get_puntero(){
	return puntero;
}
void PILA::Set_puntero(int p){
	puntero=p;
}

void PILA::Apilar(int a){
	P[++puntero]=a;
}
int PILA::Desapilar(){
	return P[puntero--];
}
bool PILA::Lleno(){
	if(puntero==M-1)
		return true;
}
bool PILA::Vacio(){
	if(puntero==-1)
		return true;
}
