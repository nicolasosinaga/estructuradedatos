#include "StdAfx.h"
#include "Concatenar.h"


Concatenar::Concatenar(void)
{
	V[n]=0;

	Tamano=0;
}
int Concatenar::Get_Tamano()
{
	return Tamano;
}
void Concatenar::Set_Tamano(int tam)
{
	Tamano=tam;
}
int Concatenar::Get_V(int pos)
{
	return V[pos];
}
void Concatenar::Set_V(int e, int pos)
{
	V[pos]=e;
}
void Concatenar::Mostrar()
{

}