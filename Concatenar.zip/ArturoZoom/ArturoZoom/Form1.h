#pragma once
#include "Concatenar.h"
namespace ArturoZoom {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	Concatenar concatenar1;
	int posicion=0;
	int posicion2=0;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::TextBox^  txtTamano1;
	protected: 

	private: System::Windows::Forms::Button^  btnDefinir;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::TextBox^  txtNumero1;

	private: System::Windows::Forms::Button^  btnIngresar;
	private: System::Windows::Forms::DataGridView^  Grid1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;
	private: System::Windows::Forms::Button^  btnConcatenar;
	private: System::Windows::Forms::Button^  btnIngresar2;
	private: System::Windows::Forms::TextBox^  txtNumero2;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Button^  btnDefinir2;
	private: System::Windows::Forms::TextBox^  txtTamano2;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::DataGridView^  Grid2;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  dataGridViewTextBoxColumn1;
	private: System::Windows::Forms::DataGridView^  Grid3;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  dataGridViewTextBoxColumn2;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->txtTamano1 = (gcnew System::Windows::Forms::TextBox());
			this->btnDefinir = (gcnew System::Windows::Forms::Button());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->txtNumero1 = (gcnew System::Windows::Forms::TextBox());
			this->btnIngresar = (gcnew System::Windows::Forms::Button());
			this->Grid1 = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->btnConcatenar = (gcnew System::Windows::Forms::Button());
			this->btnIngresar2 = (gcnew System::Windows::Forms::Button());
			this->txtNumero2 = (gcnew System::Windows::Forms::TextBox());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->btnDefinir2 = (gcnew System::Windows::Forms::Button());
			this->txtTamano2 = (gcnew System::Windows::Forms::TextBox());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->Grid2 = (gcnew System::Windows::Forms::DataGridView());
			this->dataGridViewTextBoxColumn1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Grid3 = (gcnew System::Windows::Forms::DataGridView());
			this->dataGridViewTextBoxColumn2 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid1))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid2))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid3))->BeginInit();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(24, 37);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(46, 13);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Tama�o";
			// 
			// txtTamano1
			// 
			this->txtTamano1->Location = System::Drawing::Point(113, 34);
			this->txtTamano1->Name = L"txtTamano1";
			this->txtTamano1->Size = System::Drawing::Size(100, 20);
			this->txtTamano1->TabIndex = 1;
			// 
			// btnDefinir
			// 
			this->btnDefinir->Location = System::Drawing::Point(273, 32);
			this->btnDefinir->Name = L"btnDefinir";
			this->btnDefinir->Size = System::Drawing::Size(75, 23);
			this->btnDefinir->TabIndex = 2;
			this->btnDefinir->Text = L"Definir";
			this->btnDefinir->UseVisualStyleBackColor = true;
			this->btnDefinir->Click += gcnew System::EventHandler(this, &Form1::btnDefinir_Click);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(26, 94);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(44, 13);
			this->label2->TabIndex = 3;
			this->label2->Text = L"Numero";
			// 
			// txtNumero1
			// 
			this->txtNumero1->Location = System::Drawing::Point(113, 91);
			this->txtNumero1->Name = L"txtNumero1";
			this->txtNumero1->Size = System::Drawing::Size(100, 20);
			this->txtNumero1->TabIndex = 4;
			// 
			// btnIngresar
			// 
			this->btnIngresar->Location = System::Drawing::Point(273, 89);
			this->btnIngresar->Name = L"btnIngresar";
			this->btnIngresar->Size = System::Drawing::Size(75, 23);
			this->btnIngresar->TabIndex = 5;
			this->btnIngresar->Text = L"Ingresar";
			this->btnIngresar->UseVisualStyleBackColor = true;
			this->btnIngresar->Click += gcnew System::EventHandler(this, &Form1::btnIngresar_Click);
			// 
			// Grid1
			// 
			this->Grid1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grid1->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column1});
			this->Grid1->Location = System::Drawing::Point(27, 155);
			this->Grid1->Name = L"Grid1";
			this->Grid1->Size = System::Drawing::Size(229, 146);
			this->Grid1->TabIndex = 6;
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"Numeros";
			this->Column1->Name = L"Column1";
			// 
			// btnConcatenar
			// 
			this->btnConcatenar->Location = System::Drawing::Point(544, 396);
			this->btnConcatenar->Name = L"btnConcatenar";
			this->btnConcatenar->Size = System::Drawing::Size(75, 23);
			this->btnConcatenar->TabIndex = 7;
			this->btnConcatenar->Text = L"Concatenar";
			this->btnConcatenar->UseVisualStyleBackColor = true;
			// 
			// btnIngresar2
			// 
			this->btnIngresar2->Location = System::Drawing::Point(679, 92);
			this->btnIngresar2->Name = L"btnIngresar2";
			this->btnIngresar2->Size = System::Drawing::Size(75, 23);
			this->btnIngresar2->TabIndex = 13;
			this->btnIngresar2->Text = L"Ingresar";
			this->btnIngresar2->UseVisualStyleBackColor = true;
			this->btnIngresar2->Click += gcnew System::EventHandler(this, &Form1::btnIngresar2_Click);
			// 
			// txtNumero2
			// 
			this->txtNumero2->Location = System::Drawing::Point(519, 94);
			this->txtNumero2->Name = L"txtNumero2";
			this->txtNumero2->Size = System::Drawing::Size(100, 20);
			this->txtNumero2->TabIndex = 12;
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(432, 97);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(44, 13);
			this->label3->TabIndex = 11;
			this->label3->Text = L"Numero";
			// 
			// btnDefinir2
			// 
			this->btnDefinir2->Location = System::Drawing::Point(679, 35);
			this->btnDefinir2->Name = L"btnDefinir2";
			this->btnDefinir2->Size = System::Drawing::Size(75, 23);
			this->btnDefinir2->TabIndex = 10;
			this->btnDefinir2->Text = L"Definir";
			this->btnDefinir2->UseVisualStyleBackColor = true;
			this->btnDefinir2->Click += gcnew System::EventHandler(this, &Form1::btnDefinir2_Click);
			// 
			// txtTamano2
			// 
			this->txtTamano2->Location = System::Drawing::Point(519, 37);
			this->txtTamano2->Name = L"txtTamano2";
			this->txtTamano2->Size = System::Drawing::Size(100, 20);
			this->txtTamano2->TabIndex = 9;
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(430, 40);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(46, 13);
			this->label4->TabIndex = 8;
			this->label4->Text = L"Tama�o";
			// 
			// Grid2
			// 
			this->Grid2->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grid2->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->dataGridViewTextBoxColumn1});
			this->Grid2->Location = System::Drawing::Point(433, 155);
			this->Grid2->Name = L"Grid2";
			this->Grid2->Size = System::Drawing::Size(229, 146);
			this->Grid2->TabIndex = 14;
			this->Grid2->CellContentClick += gcnew System::Windows::Forms::DataGridViewCellEventHandler(this, &Form1::Grid2_CellContentClick);
			// 
			// dataGridViewTextBoxColumn1
			// 
			this->dataGridViewTextBoxColumn1->HeaderText = L"Numeros";
			this->dataGridViewTextBoxColumn1->Name = L"dataGridViewTextBoxColumn1";
			// 
			// Grid3
			// 
			this->Grid3->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grid3->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->dataGridViewTextBoxColumn2});
			this->Grid3->Location = System::Drawing::Point(232, 332);
			this->Grid3->Name = L"Grid3";
			this->Grid3->Size = System::Drawing::Size(229, 146);
			this->Grid3->TabIndex = 15;
			// 
			// dataGridViewTextBoxColumn2
			// 
			this->dataGridViewTextBoxColumn2->HeaderText = L"Numeros";
			this->dataGridViewTextBoxColumn2->Name = L"dataGridViewTextBoxColumn2";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(1021, 545);
			this->Controls->Add(this->Grid3);
			this->Controls->Add(this->Grid2);
			this->Controls->Add(this->btnIngresar2);
			this->Controls->Add(this->txtNumero2);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->btnDefinir2);
			this->Controls->Add(this->txtTamano2);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->btnConcatenar);
			this->Controls->Add(this->Grid1);
			this->Controls->Add(this->btnIngresar);
			this->Controls->Add(this->txtNumero1);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->btnDefinir);
			this->Controls->Add(this->txtTamano1);
			this->Controls->Add(this->label1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			this->Load += gcnew System::EventHandler(this, &Form1::Form1_Load);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid1))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid2))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid3))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void Grid2_CellContentClick(System::Object^  sender, System::Windows::Forms::DataGridViewCellEventArgs^  e) {
			 }
private: System::Void Form1_Load(System::Object^  sender, System::EventArgs^  e) {
		 }
private: System::Void btnDefinir_Click(System::Object^  sender, System::EventArgs^  e) {
			 int tam;
			 tam=Convert::ToInt32(txtTamano1->Text);
			 concatenar1.Set_Tamano(tam);
			 Grid1->RowCount=tam;
		 }
private: System::Void btnDefinir2_Click(System::Object^  sender, System::EventArgs^  e) {
			 int tam;
			 tam=Convert::ToInt32(txtTamano2->Text);
			 concatenar1.Set_Tamano(tam);
			 Grid2->RowCount=tam;
		 }
private: System::Void btnIngresar_Click(System::Object^  sender, System::EventArgs^  e) {
			 int numero;
		     numero=Convert::ToInt32(txtNumero1->Text);
			 concatenar1.Set_V(numero, posicion);
			 Grid1->Rows[posicion]->Cells[0]->Value=numero;
			 posicion++;
		 }
private: System::Void btnIngresar2_Click(System::Object^  sender, System::EventArgs^  e) {
			 int numero;
		     numero=Convert::ToInt32(txtNumero2->Text);
			 concatenar1.Set_V(numero, posicion2);
			 Grid2->Rows[posicion2]->Cells[0]->Value=numero;
			 posicion2++;
		 }
};
}
nbjb

