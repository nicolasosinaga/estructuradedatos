#pragma once
#define n 50
class Concatenar
{
private:
    int V[n];
    int Tamano;
public:
	Concatenar(void);
	int Get_Tamano();
	void Set_Tamano(int tam);
	int Get_V(int pos);
	void Set_V(int e, int pos);
	void Mostrar();
};

