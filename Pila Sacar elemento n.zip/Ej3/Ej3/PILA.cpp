#include "StdAfx.h"
#include "PILA.h"


PILA::PILA(void)
{
	P[M]=0;
	puntero=-1;
}

int PILA::Get_pila(int a){
	return P[a];
}
int PILA::Get_puntero(){
	return puntero;
}
void PILA::Apilar(int b){
	P[++puntero]=b;
}
int PILA::Desapilar(){
	int c;
	c=P[puntero--];
	return c;
}
bool PILA::Lleno(){
	if(puntero==M-1)
		return true;
}
bool PILA::Vacio(){
	if(puntero==-1)
		return true;
}
