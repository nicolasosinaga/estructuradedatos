#pragma once
#define M 25
class PILA
{
private:
	int P[M];
	int puntero;
public:
	PILA(void);
	int Get_pila(int a);
	int Get_puntero();
	void Apilar(int b);
	int Desapilar();
	bool Lleno();
	bool Vacio();
};

