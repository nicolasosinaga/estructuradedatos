#include "StdAfx.h"  // #(){}[]<>\|/"+
#include "Pila.h"


Pila::Pila(void)
{
	P[Max]=0;
	Top=-1;
	Tamano=0;
}
int Pila::Get_Tamano()
{
	return Tamano;
}
void Pila::Set_Tamano(int tam)
{
	Tamano=tam;
}
void Pila::Push(int x)
{
	Top++;
	P[Top]=x;
}
int Pila::Pop()
{int x;
	x=P[Top];
	Top--;
	return x;
}
bool Pila::Full()
{if(Top>=Tamano-1)
    return true;
else
	return false;
}
bool Pila::Empty()
{if(Top == -1)
    return true;
else
	return false;
}
void Pila::Invertir(int x[])
{int aux;
 for(int i=0; i<Tamano/2; i++)
  {aux=x[i];
   x[i]=x[Tamano];
   x[Tamano]=aux;
  }
}