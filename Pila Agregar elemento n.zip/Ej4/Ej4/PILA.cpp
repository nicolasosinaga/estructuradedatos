#include "StdAfx.h"
#include "PILA.h"


PILA::PILA(void)
{
	P[M]=0;
	puntero=-1;
}
void PILA::Apilar(int x){
P[++puntero]=x;
}
int PILA::Desapilar(){
int a;
a=P[puntero--];
return a;
}
bool PILA::Vacio(){
	if(puntero==-1)
	return true;
}
bool PILA::Lleno(){
	if(puntero==M-1)
		return true;
}
int PILA::Getpuntero(){
	return puntero;
}