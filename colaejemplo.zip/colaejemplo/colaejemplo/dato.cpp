#include "StdAfx.h"
#include "dato.h"


dato::dato(void)
{
}


dato::~dato(void)
{
}
