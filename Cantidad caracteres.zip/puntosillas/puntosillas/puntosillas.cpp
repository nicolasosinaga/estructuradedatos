// puntosillas.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "conio.h"
#include "iostream"

using namespace std;

#define N 50
void main()
{ char M[N];
 
  int pal=0, tam;
  cout << "Ingrese  texto: " ;
  cin.getline(M,N,'\n');
  cout <<"\n "<<M;
  tam = strlen(M); cout<<"---- "<< tam <<"\n";
  for(int k=0; k<tam;k++)
     {if(M[k] != ' ' && k==0)
        { M[k] = toupper(M[k]);
          pal= pal +1;
        }
	  if(M[k] != ' ' && M[k-1]==' ')
          {M[k] = toupper(M[k]);
	       pal= pal +1;
          }
     }
 
  cout <<"\n "<<M<<"  cant palabras  "<< pal;
  _getch();
}

