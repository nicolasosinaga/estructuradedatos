#pragma once
#include "Final.h"
namespace ExamenFinal {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	Final A;
	int tamano=0;
	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::TextBox^  txtNumeros;
	private: System::Windows::Forms::Button^  btnDefinir;

	protected: 

	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Button^  btnMostrar;
	private: System::Windows::Forms::DataGridView^  Grid1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;

	protected: 


	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->txtNumeros = (gcnew System::Windows::Forms::TextBox());
			this->btnDefinir = (gcnew System::Windows::Forms::Button());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->btnMostrar = (gcnew System::Windows::Forms::Button());
			this->Grid1 = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid1))->BeginInit();
			this->SuspendLayout();
			// 
			// txtNumeros
			// 
			this->txtNumeros->Location = System::Drawing::Point(78, 50);
			this->txtNumeros->Name = L"txtNumeros";
			this->txtNumeros->Size = System::Drawing::Size(100, 20);
			this->txtNumeros->TabIndex = 1;
			// 
			// btnDefinir
			// 
			this->btnDefinir->Location = System::Drawing::Point(197, 47);
			this->btnDefinir->Name = L"btnDefinir";
			this->btnDefinir->Size = System::Drawing::Size(75, 23);
			this->btnDefinir->TabIndex = 2;
			this->btnDefinir->Text = L"Definir";
			this->btnDefinir->UseVisualStyleBackColor = true;
			this->btnDefinir->Click += gcnew System::EventHandler(this, &Form1::btnDefinir_Click);
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(11, 52);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(49, 13);
			this->label1->TabIndex = 3;
			this->label1->Text = L"Numeros";
			// 
			// btnMostrar
			// 
			this->btnMostrar->Location = System::Drawing::Point(197, 100);
			this->btnMostrar->Name = L"btnMostrar";
			this->btnMostrar->Size = System::Drawing::Size(75, 23);
			this->btnMostrar->TabIndex = 4;
			this->btnMostrar->Text = L"Mostrar";
			this->btnMostrar->UseVisualStyleBackColor = true;
			this->btnMostrar->Click += gcnew System::EventHandler(this, &Form1::btnMostrar_Click);
			// 
			// Grid1
			// 
			this->Grid1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grid1->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column1});
			this->Grid1->Location = System::Drawing::Point(28, 143);
			this->Grid1->Name = L"Grid1";
			this->Grid1->Size = System::Drawing::Size(230, 111);
			this->Grid1->TabIndex = 5;
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"Numeros";
			this->Column1->Name = L"Column1";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(284, 262);
			this->Controls->Add(this->Grid1);
			this->Controls->Add(this->btnMostrar);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->btnDefinir);
			this->Controls->Add(this->txtNumeros);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
		// #(){}[]<>\|/"+^
#pragma endregion
	private: System::Void btnDefinir_Click(System::Object^  sender, System::EventArgs^  e) {
				 int tam;
				 tam=Convert::ToInt32(txtNumeros->Text);
				 A.Set_Tamano(tam);
				 Grid1->RowCount=tam;
			 }
private: System::Void btnMostrar_Click(System::Object^  sender, System::EventArgs^  e) {
			 int x=1;
			 int v;
			 do
			 {A.Set_Vector(x, tamano);
			 v=A.Get_Vector(tamano);
			 Grid1->Rows[tamano]->Cells[0]->Value=v;
			 x++;
			 tamano++;
			 }while(x<=A.Get_Tamano());
		 }
};
}

