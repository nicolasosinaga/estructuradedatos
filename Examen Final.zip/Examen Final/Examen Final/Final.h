#pragma once // #(){}[]<>\|/"+^
#define Max 25
class Final
{private:
int V[Max];
int Tamano;
public:
	Final(void);
	int Get_Tamano();
	void Set_Tamano(int tam);
	int Get_Vector(int x);
	void Set_Vector(int x, int y);

};

