#include "StdAfx.h" // #(){}[]<>\|/"+^*
#include "Final.h"


Final::Final(void)
{
	V[Max]=0;
	Tamano=0;
}
int Final::Get_Tamano()
{
	return Tamano;
}
void Final::Set_Tamano(int x)
{
	Tamano=x;
}
int Final::Get_Vector(int x)
{
	return V[x];
}
void Final::Set_Vector(int x, int y)
{
  V[y]=x*x;
}
