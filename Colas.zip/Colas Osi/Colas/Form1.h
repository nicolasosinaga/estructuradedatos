#pragma once
#include "Cola.h"
namespace Colas {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	Cola A;
	int pos=0;
	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	protected: 
	private: System::Windows::Forms::TextBox^  txtTamano;
	private: System::Windows::Forms::Button^  btnDefinir;
	private: System::Windows::Forms::Button^  btnEncolar;
	private: System::Windows::Forms::TextBox^  txtNumero;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::TextBox^  txtNumero2;
	private: System::Windows::Forms::DataGridView^  Grid1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;
	private: System::Windows::Forms::Button^  btnSacar;
	private: System::Windows::Forms::TextBox^  txtPosicion;

	private: System::Windows::Forms::TextBox^  txtPosicion2;


	private: System::Windows::Forms::Label^  label3;


	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->txtTamano = (gcnew System::Windows::Forms::TextBox());
			this->btnDefinir = (gcnew System::Windows::Forms::Button());
			this->btnEncolar = (gcnew System::Windows::Forms::Button());
			this->txtNumero = (gcnew System::Windows::Forms::TextBox());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->txtNumero2 = (gcnew System::Windows::Forms::TextBox());
			this->Grid1 = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->btnSacar = (gcnew System::Windows::Forms::Button());
			this->txtPosicion = (gcnew System::Windows::Forms::TextBox());
			this->txtPosicion2 = (gcnew System::Windows::Forms::TextBox());
			this->label3 = (gcnew System::Windows::Forms::Label());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid1))->BeginInit();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(12, 26);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(46, 13);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Tamano";
			// 
			// txtTamano
			// 
			this->txtTamano->Location = System::Drawing::Point(121, 23);
			this->txtTamano->Name = L"txtTamano";
			this->txtTamano->Size = System::Drawing::Size(100, 20);
			this->txtTamano->TabIndex = 1;
			// 
			// btnDefinir
			// 
			this->btnDefinir->Location = System::Drawing::Point(264, 21);
			this->btnDefinir->Name = L"btnDefinir";
			this->btnDefinir->Size = System::Drawing::Size(75, 23);
			this->btnDefinir->TabIndex = 2;
			this->btnDefinir->Text = L"Definir";
			this->btnDefinir->UseVisualStyleBackColor = true;
			this->btnDefinir->Click += gcnew System::EventHandler(this, &Form1::btnDefinir_Click);
			// 
			// btnEncolar
			// 
			this->btnEncolar->Location = System::Drawing::Point(264, 66);
			this->btnEncolar->Name = L"btnEncolar";
			this->btnEncolar->Size = System::Drawing::Size(75, 23);
			this->btnEncolar->TabIndex = 5;
			this->btnEncolar->Text = L"Encolar";
			this->btnEncolar->UseVisualStyleBackColor = true;
			this->btnEncolar->Click += gcnew System::EventHandler(this, &Form1::btnEncolar_Click);
			// 
			// txtNumero
			// 
			this->txtNumero->Location = System::Drawing::Point(121, 68);
			this->txtNumero->Name = L"txtNumero";
			this->txtNumero->Size = System::Drawing::Size(100, 20);
			this->txtNumero->TabIndex = 4;
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(14, 93);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(44, 13);
			this->label2->TabIndex = 3;
			this->label2->Text = L"Numero";
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(264, 113);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(75, 23);
			this->button1->TabIndex = 7;
			this->button1->Text = L"Desencolar";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Form1::button1_Click);
			// 
			// txtNumero2
			// 
			this->txtNumero2->Location = System::Drawing::Point(121, 115);
			this->txtNumero2->Name = L"txtNumero2";
			this->txtNumero2->Size = System::Drawing::Size(100, 20);
			this->txtNumero2->TabIndex = 6;
			// 
			// Grid1
			// 
			this->Grid1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grid1->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column1});
			this->Grid1->Location = System::Drawing::Point(12, 353);
			this->Grid1->Name = L"Grid1";
			this->Grid1->Size = System::Drawing::Size(340, 160);
			this->Grid1->TabIndex = 8;
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"Numero";
			this->Column1->Name = L"Column1";
			// 
			// btnSacar
			// 
			this->btnSacar->Location = System::Drawing::Point(264, 181);
			this->btnSacar->Name = L"btnSacar";
			this->btnSacar->Size = System::Drawing::Size(63, 32);
			this->btnSacar->TabIndex = 9;
			this->btnSacar->Text = L"Sacar";
			this->btnSacar->UseVisualStyleBackColor = true;
			this->btnSacar->Click += gcnew System::EventHandler(this, &Form1::button2_Click);
			// 
			// txtPosicion
			// 
			this->txtPosicion->Location = System::Drawing::Point(121, 169);
			this->txtPosicion->Name = L"txtPosicion";
			this->txtPosicion->Size = System::Drawing::Size(100, 20);
			this->txtPosicion->TabIndex = 10;
			// 
			// txtPosicion2
			// 
			this->txtPosicion2->Location = System::Drawing::Point(121, 209);
			this->txtPosicion2->Name = L"txtPosicion2";
			this->txtPosicion2->Size = System::Drawing::Size(100, 20);
			this->txtPosicion2->TabIndex = 11;
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(14, 172);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(47, 13);
			this->label3->TabIndex = 12;
			this->label3->Text = L"Posicion";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(381, 525);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->txtPosicion2);
			this->Controls->Add(this->txtPosicion);
			this->Controls->Add(this->btnSacar);
			this->Controls->Add(this->Grid1);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->txtNumero2);
			this->Controls->Add(this->btnEncolar);
			this->Controls->Add(this->txtNumero);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->btnDefinir);
			this->Controls->Add(this->txtTamano);
			this->Controls->Add(this->label1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnDefinir_Click(System::Object^  sender, System::EventArgs^  e) {
				 int tam;
				 tam=System::Convert::ToInt32(txtTamano->Text);
				 Grid1->RowCount=tam;

			 }
private: System::Void btnEncolar_Click(System::Object^  sender, System::EventArgs^  e) {
			 int x;
			 x=System::Convert::ToInt32(txtNumero->Text);
			 A.Encolar(x);
			 Grid1->Rows[pos]->Cells[0]->Value=x;
			 pos++;
		 }
private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
			 int x;
			 x=A.Desencolar();
			 txtNumero2->Text=Convert::ToString(x);
			 Grid1->Rows->RemoveAt(0);
			 
		 }
private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e) {
			 int posi;
			 int x;
			 posi=System::Convert::ToInt32(txtPosicion->Text);
			 for(int i=0; i<posi; i++)
				 {x=A.Desencolar();
			     }
			 txtPosicion2->Text=Convert::ToString(x);
			 Grid1->Rows->RemoveAt(posi-1);
		 }
};
}


// #(){}[]<>\|/"+
