#include "StdAfx.h" // #(){}[]<>\|/"+
#include "Cola.h"


Cola::Cola(void)
{
	Frente=0;
	Final=-1;
	C[MAX]=0;
}
void Cola::Encolar(int x)
{
	Final++;
	C[Final]=x;
}
int Cola::Desencolar()
{int x;
	x=C[Frente];
	Frente++;
	return x;
}
bool Cola::Full()
{
	if(Final>MAX)
    return true;
else
	return false;

}
bool Cola::Empty()
{
	if(Final==-1)
		return true;
	else
	    return false;
}