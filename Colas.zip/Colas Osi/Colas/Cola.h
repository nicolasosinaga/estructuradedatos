#pragma once // #(){}[]<>\|/"+
#define MAX 25
class Cola
{private:
int Frente;
int Final;
int C[MAX];
 public:
	Cola(void);
	void Encolar(int x);
	int Desencolar();
	bool Full();
	bool Empty();
};

