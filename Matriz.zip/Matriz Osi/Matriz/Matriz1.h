#pragma once // #(){}[]<>\|/"+^
#define I 15
#define J 15
class Matriz1
{
private:
	int Filas;
	int Columnas;
	int M[I][J];
public:
	Matriz1(void);
	void Set_Filas(int x);
	int Get_Filas();
	void Set_Columnas(int x);
	int Get_Columnas();
	void Set_Elemento(int x, int y, int z);
	int Get_Elemento(int x, int y);
	int SumaTotal(int x, int y);
	int Diagonal(int x, int y);
};

