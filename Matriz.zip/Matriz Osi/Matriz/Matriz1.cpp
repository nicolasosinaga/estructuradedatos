#include "StdAfx.h" // #(){}[]<>\|/"+
#include "Matriz1.h"


Matriz1::Matriz1(void)
{
}
void Matriz1::Set_Filas(int x)
{
	Filas=x;
}
int Matriz1::Get_Filas()
{
	return Filas;
}
void Matriz1::Set_Columnas(int x)
{
	Columnas=x;
}
int Matriz1::Get_Columnas()
{
	return Columnas;
}
void Matriz1::Set_Elemento(int x, int y, int z)
{
	M[x][y]=z;
}
int Matriz1::Get_Elemento(int x, int y)
{
	return M[x][y];
}
int Matriz1::SumaTotal(int x, int y)
{int s=0;
 for(int i=0;i<x;i++)
  {for(int j=0; j<y; j++)
   {
	 s=s+Get_Elemento(i,j);
   }
  }
 return s;
}
int Matriz1::Diagonal(int x, int y)
{int s=0;
 for(int i=0;i<x;i++)
  {for(int j=0; j<y; j++)
   {if(i==j)
     {
		 s=s+Get_Elemento(i,j);
     }
   }
  }
 return s;
}


