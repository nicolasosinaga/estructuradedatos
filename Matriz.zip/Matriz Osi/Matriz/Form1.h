#pragma once
#include "Matriz1.h"
namespace Matriz {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	Matriz1 A;
	int pos1=0;
	int pos2=0;
	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	protected: 
	private: System::Windows::Forms::TextBox^  txtFilas;
	private: System::Windows::Forms::Button^  btnDefinir;
	private: System::Windows::Forms::TextBox^  txtColumnas;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::TextBox^  txtNumero;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Button^  btnIngresar;
	private: System::Windows::Forms::DataGridView^  Grid1;
	private: System::Windows::Forms::Button^  btnDiagonal;
	private: System::Windows::Forms::TextBox^  txtDiagonal;
	private: System::Windows::Forms::TextBox^  txtSuma;
	private: System::Windows::Forms::Button^  btnTotal;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->txtFilas = (gcnew System::Windows::Forms::TextBox());
			this->btnDefinir = (gcnew System::Windows::Forms::Button());
			this->txtColumnas = (gcnew System::Windows::Forms::TextBox());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->txtNumero = (gcnew System::Windows::Forms::TextBox());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->btnIngresar = (gcnew System::Windows::Forms::Button());
			this->Grid1 = (gcnew System::Windows::Forms::DataGridView());
			this->btnDiagonal = (gcnew System::Windows::Forms::Button());
			this->txtDiagonal = (gcnew System::Windows::Forms::TextBox());
			this->txtSuma = (gcnew System::Windows::Forms::TextBox());
			this->btnTotal = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid1))->BeginInit();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(12, 41);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(70, 13);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Tamano Filas";
			// 
			// txtFilas
			// 
			this->txtFilas->Location = System::Drawing::Point(113, 38);
			this->txtFilas->Name = L"txtFilas";
			this->txtFilas->Size = System::Drawing::Size(99, 20);
			this->txtFilas->TabIndex = 1;
			// 
			// btnDefinir
			// 
			this->btnDefinir->Location = System::Drawing::Point(240, 38);
			this->btnDefinir->Name = L"btnDefinir";
			this->btnDefinir->Size = System::Drawing::Size(60, 54);
			this->btnDefinir->TabIndex = 2;
			this->btnDefinir->Text = L"Definir";
			this->btnDefinir->UseVisualStyleBackColor = true;
			this->btnDefinir->Click += gcnew System::EventHandler(this, &Form1::btnDefinir_Click);
			// 
			// txtColumnas
			// 
			this->txtColumnas->Location = System::Drawing::Point(113, 76);
			this->txtColumnas->Name = L"txtColumnas";
			this->txtColumnas->Size = System::Drawing::Size(99, 20);
			this->txtColumnas->TabIndex = 4;
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(12, 79);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(95, 13);
			this->label2->TabIndex = 3;
			this->label2->Text = L"Tamano Columnas";
			// 
			// txtNumero
			// 
			this->txtNumero->Location = System::Drawing::Point(113, 128);
			this->txtNumero->Name = L"txtNumero";
			this->txtNumero->Size = System::Drawing::Size(99, 20);
			this->txtNumero->TabIndex = 6;
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(12, 131);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(44, 13);
			this->label3->TabIndex = 5;
			this->label3->Text = L"Numero";
			// 
			// btnIngresar
			// 
			this->btnIngresar->Location = System::Drawing::Point(242, 122);
			this->btnIngresar->Name = L"btnIngresar";
			this->btnIngresar->Size = System::Drawing::Size(58, 30);
			this->btnIngresar->TabIndex = 7;
			this->btnIngresar->Text = L"Ingesar";
			this->btnIngresar->UseVisualStyleBackColor = true;
			this->btnIngresar->Click += gcnew System::EventHandler(this, &Form1::btnIngresar_Click);
			// 
			// Grid1
			// 
			this->Grid1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grid1->Location = System::Drawing::Point(29, 211);
			this->Grid1->Name = L"Grid1";
			this->Grid1->Size = System::Drawing::Size(255, 137);
			this->Grid1->TabIndex = 8;
			// 
			// btnDiagonal
			// 
			this->btnDiagonal->Location = System::Drawing::Point(371, 360);
			this->btnDiagonal->Name = L"btnDiagonal";
			this->btnDiagonal->Size = System::Drawing::Size(107, 33);
			this->btnDiagonal->TabIndex = 9;
			this->btnDiagonal->Text = L"Sumar Diagonal";
			this->btnDiagonal->UseVisualStyleBackColor = true;
			this->btnDiagonal->Click += gcnew System::EventHandler(this, &Form1::btnDiagonal_Click);
			// 
			// txtDiagonal
			// 
			this->txtDiagonal->Location = System::Drawing::Point(266, 367);
			this->txtDiagonal->Name = L"txtDiagonal";
			this->txtDiagonal->Size = System::Drawing::Size(99, 20);
			this->txtDiagonal->TabIndex = 10;
			// 
			// txtSuma
			// 
			this->txtSuma->Location = System::Drawing::Point(15, 367);
			this->txtSuma->Name = L"txtSuma";
			this->txtSuma->Size = System::Drawing::Size(99, 20);
			this->txtSuma->TabIndex = 12;
			// 
			// btnTotal
			// 
			this->btnTotal->Location = System::Drawing::Point(129, 360);
			this->btnTotal->Name = L"btnTotal";
			this->btnTotal->Size = System::Drawing::Size(107, 33);
			this->btnTotal->TabIndex = 11;
			this->btnTotal->Text = L"Suma Total";
			this->btnTotal->UseVisualStyleBackColor = true;
			this->btnTotal->Click += gcnew System::EventHandler(this, &Form1::btnTotal_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(490, 396);
			this->Controls->Add(this->txtSuma);
			this->Controls->Add(this->btnTotal);
			this->Controls->Add(this->txtDiagonal);
			this->Controls->Add(this->btnDiagonal);
			this->Controls->Add(this->Grid1);
			this->Controls->Add(this->btnIngresar);
			this->Controls->Add(this->txtNumero);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->txtColumnas);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->btnDefinir);
			this->Controls->Add(this->txtFilas);
			this->Controls->Add(this->label1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnDefinir_Click(System::Object^  sender, System::EventArgs^  e) {
				 int tam1,tam2;
				 tam1=Convert::ToInt32(txtFilas->Text);
				 A.Set_Filas(tam1);
				 Grid1->RowCount=tam1;
				 tam2=Convert::ToInt32(txtColumnas->Text);
				 A.Set_Columnas(tam2);
				 Grid1->ColumnCount=tam2;
			 }
private: System::Void btnIngresar_Click(System::Object^  sender, System::EventArgs^  e) {
			 int x;
			 x=Convert::ToInt32(txtNumero->Text);
			 A.Set_Elemento(pos1,pos2,x);
			 Grid1->Rows[pos1]->Cells[pos2]->Value=x;
			 pos2++;
			 if(pos2==A.Get_Columnas())
               {
				   pos2=0;
				   pos1++;
			   }
		 }
private: System::Void btnTotal_Click(System::Object^  sender, System::EventArgs^  e) {
			 txtSuma->Text=Convert::ToString(A.SumaTotal(A.Get_Filas(), A.Get_Columnas()));
		 }
private: System::Void btnDiagonal_Click(System::Object^  sender, System::EventArgs^  e) {
			 if(A.Get_Filas()==A.Get_Columnas())
              {txtDiagonal->Text=Convert::ToString(A.Diagonal(A.Get_Filas(), A.Get_Columnas()));
			  }
			 else
			  {MessageBox::Show("La matriz no es cuadrada");
			  }
		 }
 };
}

// #(){}[]<>\|/"+

       