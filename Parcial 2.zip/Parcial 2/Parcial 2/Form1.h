#pragma once
#include "Matriz.h"
namespace Parcial2 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	Matriz A;
	int pos1=0;
	int pos2=0;

	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	protected: 
	private: System::Windows::Forms::TextBox^  txtFilas;
	private: System::Windows::Forms::TextBox^  txtColumnas;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Button^  btnDefinir;
	private: System::Windows::Forms::TextBox^  txtNumero;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Button^  btnIngresar;
	private: System::Windows::Forms::DataGridView^  Grid1;
	private: System::Windows::Forms::Button^  btnAnalizar;
	private: System::Windows::Forms::TextBox^  txtAnalizar;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->txtFilas = (gcnew System::Windows::Forms::TextBox());
			this->txtColumnas = (gcnew System::Windows::Forms::TextBox());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->btnDefinir = (gcnew System::Windows::Forms::Button());
			this->txtNumero = (gcnew System::Windows::Forms::TextBox());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->btnIngresar = (gcnew System::Windows::Forms::Button());
			this->Grid1 = (gcnew System::Windows::Forms::DataGridView());
			this->btnAnalizar = (gcnew System::Windows::Forms::Button());
			this->txtAnalizar = (gcnew System::Windows::Forms::TextBox());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid1))->BeginInit();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(29, 34);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(28, 13);
			this->label1->TabIndex = 0;
			this->label1->Text = L"Filas";
			// 
			// txtFilas
			// 
			this->txtFilas->Location = System::Drawing::Point(92, 31);
			this->txtFilas->Name = L"txtFilas";
			this->txtFilas->Size = System::Drawing::Size(89, 20);
			this->txtFilas->TabIndex = 1;
			// 
			// txtColumnas
			// 
			this->txtColumnas->Location = System::Drawing::Point(92, 69);
			this->txtColumnas->Name = L"txtColumnas";
			this->txtColumnas->Size = System::Drawing::Size(89, 20);
			this->txtColumnas->TabIndex = 3;
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(29, 72);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(53, 13);
			this->label2->TabIndex = 2;
			this->label2->Text = L"Columnas";
			// 
			// btnDefinir
			// 
			this->btnDefinir->Location = System::Drawing::Point(229, 41);
			this->btnDefinir->Name = L"btnDefinir";
			this->btnDefinir->Size = System::Drawing::Size(65, 44);
			this->btnDefinir->TabIndex = 4;
			this->btnDefinir->Text = L"Definir";
			this->btnDefinir->UseVisualStyleBackColor = true;
			this->btnDefinir->Click += gcnew System::EventHandler(this, &Form1::btnDefinir_Click);
			// 
			// txtNumero
			// 
			this->txtNumero->Location = System::Drawing::Point(92, 120);
			this->txtNumero->Name = L"txtNumero";
			this->txtNumero->Size = System::Drawing::Size(89, 20);
			this->txtNumero->TabIndex = 6;
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(29, 123);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(44, 13);
			this->label3->TabIndex = 5;
			this->label3->Text = L"Numero";
			// 
			// btnIngresar
			// 
			this->btnIngresar->Location = System::Drawing::Point(229, 115);
			this->btnIngresar->Name = L"btnIngresar";
			this->btnIngresar->Size = System::Drawing::Size(73, 28);
			this->btnIngresar->TabIndex = 7;
			this->btnIngresar->Text = L"Ingresar";
			this->btnIngresar->UseVisualStyleBackColor = true;
			this->btnIngresar->Click += gcnew System::EventHandler(this, &Form1::btnIngresar_Click);
			// 
			// Grid1
			// 
			this->Grid1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grid1->Location = System::Drawing::Point(24, 172);
			this->Grid1->Name = L"Grid1";
			this->Grid1->Size = System::Drawing::Size(277, 113);
			this->Grid1->TabIndex = 8;
			// 
			// btnAnalizar
			// 
			this->btnAnalizar->Location = System::Drawing::Point(255, 316);
			this->btnAnalizar->Name = L"btnAnalizar";
			this->btnAnalizar->Size = System::Drawing::Size(86, 30);
			this->btnAnalizar->TabIndex = 9;
			this->btnAnalizar->Text = L"Analizar";
			this->btnAnalizar->UseVisualStyleBackColor = true;
			this->btnAnalizar->Click += gcnew System::EventHandler(this, &Form1::btnAnalizar_Click);
			// 
			// txtAnalizar
			// 
			this->txtAnalizar->Location = System::Drawing::Point(112, 322);
			this->txtAnalizar->Name = L"txtAnalizar";
			this->txtAnalizar->Size = System::Drawing::Size(112, 20);
			this->txtAnalizar->TabIndex = 10;
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(364, 360);
			this->Controls->Add(this->txtAnalizar);
			this->Controls->Add(this->btnAnalizar);
			this->Controls->Add(this->Grid1);
			this->Controls->Add(this->btnIngresar);
			this->Controls->Add(this->txtNumero);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->btnDefinir);
			this->Controls->Add(this->txtColumnas);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->txtFilas);
			this->Controls->Add(this->label1);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnDefinir_Click(System::Object^  sender, System::EventArgs^  e) {
				 int tam1, tam2;
				 tam1=Convert::ToInt32(txtFilas->Text);
				 A.Set_Filas(tam1);
				 Grid1->RowCount=tam1;
				 tam2=Convert::ToInt32(txtColumnas->Text);
				 A.Set_Columnas(tam2);
				 Grid1->ColumnCount=tam2;
			 }
private: System::Void btnIngresar_Click(System::Object^  sender, System::EventArgs^  e) {
			 int x;
			 x=Convert::ToInt32(txtNumero->Text);
			 A.Set_Elemento(pos1, pos2, x);
			 Grid1->Rows[pos1]->Cells[pos2]->Value=x;
			 pos2++;
			 if(pos2== A.Get_Columnas())
               {
				   pos2=0;
				   pos1++;
			   }
		 }
private: System::Void btnAnalizar_Click(System::Object^  sender, System::EventArgs^  e) {
           int x;
		   x=A.Analizar(A.Get_Filas(), A.Get_Columnas());
		   if(x!=0)
			   {MessageBox::Show("No todos los numeros son pares");
		       }else
				   {MessageBox::Show("Todos los numeros son pares");
			       }
		 }
};
}

// #(){}[]<>\|/"+^
