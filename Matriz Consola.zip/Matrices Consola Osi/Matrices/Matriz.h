#pragma once
class Matriz
{
private:
 int mat[10][10];
 int n;
 int m;
public:
	Matriz(void);
	~Matriz(void);
	Matriz(int _n,int _m);
	void setFil(int f);
	void setCol(int c);
	int getFil();
	int getCol();
	void setElem(int x,int i, int j);
	int getElem(int i, int j);
	void definir();
	void mostrar();
	void sumarmatrices(Matriz mat1, Matriz mat2);

};

