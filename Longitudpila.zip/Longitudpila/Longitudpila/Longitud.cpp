#include "StdAfx.h"
#include "Longitud.h"


Longitud::Longitud(void)
{
	top=-1;
	A[N]= 0;
}
bool Longitud::empty()
{
	if(top==-1)
		return true;
	else
		return false;
}
bool Longitud::full()
	{
		if(top>= N)
			return true;
		else
			return false;
	}
bool Longitud::Push(int x)
{
	if(full()==true)
		return false;
	else
		{
			A[++top]=x;
			return true;
		}

}
int Longitud::Pop(int x)
	{
		if(empty()==true)
			return false;
		else
		{
			x = A[top--];
			return true;
		}
	}
int Longitud::Get_top()
{
	return top;
}