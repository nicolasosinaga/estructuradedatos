#pragma once
#include "stdafx.h"
#include <iostream>

#define N 5

using namespace std;

class Longitud
{
private:
	int top;
	int A[N];
public:
	Longitud(void);
	bool Push(int x);
	int Pop(int x);
	bool empty();
	bool full();
	int Get_top();
};

