#pragma once
#include "Longitud.h"


namespace Longitudpila {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace std;

	Longitud m;
	 int t;
	int pos=0;
	int pos1=1;
	int pos2=0;
	/// <summary>
	/// Summary for Form1
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Button^  btnIng;
	protected: 
	private: System::Windows::Forms::TextBox^  txtIng;
	private: System::Windows::Forms::DataGridView^  Grid;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;
	private: System::Windows::Forms::Button^  Calcular;
	private: System::Windows::Forms::TextBox^  txtCalcular;
	private: System::Windows::Forms::TextBox^  txtTam;
	private: System::Windows::Forms::Button^  btnTam;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->btnIng = (gcnew System::Windows::Forms::Button());
			this->txtIng = (gcnew System::Windows::Forms::TextBox());
			this->Grid = (gcnew System::Windows::Forms::DataGridView());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Calcular = (gcnew System::Windows::Forms::Button());
			this->txtCalcular = (gcnew System::Windows::Forms::TextBox());
			this->txtTam = (gcnew System::Windows::Forms::TextBox());
			this->btnTam = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid))->BeginInit();
			this->SuspendLayout();
			// 
			// btnIng
			// 
			this->btnIng->Location = System::Drawing::Point(240, 48);
			this->btnIng->Name = L"btnIng";
			this->btnIng->Size = System::Drawing::Size(75, 23);
			this->btnIng->TabIndex = 0;
			this->btnIng->Text = L"Ingresar";
			this->btnIng->UseVisualStyleBackColor = true;
			this->btnIng->Click += gcnew System::EventHandler(this, &Form1::btnIng_Click);
			// 
			// txtIng
			// 
			this->txtIng->Location = System::Drawing::Point(62, 51);
			this->txtIng->Name = L"txtIng";
			this->txtIng->Size = System::Drawing::Size(100, 20);
			this->txtIng->TabIndex = 1;
			// 
			// Grid
			// 
			this->Grid->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->Grid->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(1) {this->Column1});
			this->Grid->Location = System::Drawing::Point(62, 117);
			this->Grid->Name = L"Grid";
			this->Grid->Size = System::Drawing::Size(240, 150);
			this->Grid->TabIndex = 2;
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"Column1";
			this->Column1->Name = L"Column1";
			// 
			// Calcular
			// 
			this->Calcular->Location = System::Drawing::Point(480, 117);
			this->Calcular->Name = L"Calcular";
			this->Calcular->Size = System::Drawing::Size(75, 23);
			this->Calcular->TabIndex = 3;
			this->Calcular->Text = L"Calcular";
			this->Calcular->UseVisualStyleBackColor = true;
			this->Calcular->Click += gcnew System::EventHandler(this, &Form1::Calcular_Click);
			// 
			// txtCalcular
			// 
			this->txtCalcular->Location = System::Drawing::Point(350, 117);
			this->txtCalcular->Name = L"txtCalcular";
			this->txtCalcular->Size = System::Drawing::Size(100, 20);
			this->txtCalcular->TabIndex = 4;
			// 
			// txtTam
			// 
			this->txtTam->Location = System::Drawing::Point(62, 19);
			this->txtTam->Name = L"txtTam";
			this->txtTam->Size = System::Drawing::Size(100, 20);
			this->txtTam->TabIndex = 5;
			// 
			// btnTam
			// 
			this->btnTam->Location = System::Drawing::Point(240, 19);
			this->btnTam->Name = L"btnTam";
			this->btnTam->Size = System::Drawing::Size(75, 23);
			this->btnTam->TabIndex = 6;
			this->btnTam->Text = L"Ingresar";
			this->btnTam->UseVisualStyleBackColor = true;
			this->btnTam->Click += gcnew System::EventHandler(this, &Form1::btnTam_Click);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(608, 295);
			this->Controls->Add(this->btnTam);
			this->Controls->Add(this->txtTam);
			this->Controls->Add(this->txtCalcular);
			this->Controls->Add(this->Calcular);
			this->Controls->Add(this->Grid);
			this->Controls->Add(this->txtIng);
			this->Controls->Add(this->btnIng);
			this->Name = L"Form1";
			this->Text = L"Form1";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->Grid))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void btnIng_Click(System::Object^  sender, System::EventArgs^  e) 
			 {
				 int el;
				 el = System::Convert::ToInt32(txtIng->Text);
				 if(m.full())
					 MessageBox::Show("pila llena");
				 else
				 {
					 m.Push(el);
					 Grid->Rows[pos]->Cells[0]->Value=el;	
					 
					   pos++;
					  
				 }
			 }
private: System::Void btnTam_Click(System::Object^  sender, System::EventArgs^  e) {
			
			 t= System::Convert::ToInt32(txtTam->Text);
			 Grid->RowCount=t;
			 Grid->ColumnCount=2;

		 }
private: System::Void Calcular_Click(System::Object^  sender, System::EventArgs^  e) {
			 
			 {
				for(int i=0; i<t; i++)
				   { Grid->Rows[pos2]->Cells[1]->Value=pos1;
				    pos1++;
					pos2++;

				 }
			 }
		 }
};
}

