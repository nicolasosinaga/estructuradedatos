#pragma once
class Operaciones
{
public:
	Operaciones(void);
	
};

