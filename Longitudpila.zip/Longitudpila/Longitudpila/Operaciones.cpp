#include "StdAfx.h"
#include "Operaciones.h"


Operaciones::Operaciones(void)
{
}
